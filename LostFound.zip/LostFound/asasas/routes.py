from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import User, LostItem, FoundItem
from app import db

main = Blueprint('main', __name__)

@main.route('/')
def index():
    lost_items = LostItem.query.all()
    return render_template('index.html', lost_items=lost_items)

@main.route('/report-lost', methods=['GET', 'POST'])
@login_required
def report_lost():
    if request.method == 'POST':
        owner_name = request.form['owner_name']
        item_desc = request.form['item_desc']
        last_seen_location = request.form['last_seen_location']
        image_url = request.form.get('image_url')

        new_item = LostItem(owner_name=owner_name,
                          item_desc=item_desc,
                          last_seen_location=last_seen_location,
                          image_url=image_url,
                          user_id=current_user.id)
        db.session.add(new_item)
        db.session.commit()
        return redirect(url_for('main.index'))

    return render_template('report_lost.html')

@main.route('/report-found', methods=['GET', 'POST'])
@login_required
def report_found():
    if request.method == 'POST':
        finder_name = request.form['finder_name']
        contact_info = request.form['contact_info']
        item_desc = request.form['item_desc']
        found_location = request.form.get('found_location', 'Not specified')

        found_item = FoundItem(finder_name=finder_name,
                             contact_info=contact_info,
                             item_desc=item_desc,
                             found_location=found_location,
                             user_id=current_user.id)
        db.session.add(found_item)
        db.session.commit()
        return redirect(url_for('main.index'))

    return render_template('report_found.html')

@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('main.index'))
        flash('Please check your login details and try again.')
    return render_template('login.html')

@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email address already exists')
            return redirect(url_for('main.register'))
        new_user = User(username=username,
                      email=email,
                      password=generate_password_hash(password, method='pbkdf2:sha256'))
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('main.login'))
    return render_template('register.html')

@main.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))

@main.route('/admin')
@login_required
def admin():
    if not current_user.is_admin:
        return redirect(url_for('main.index'))
    lost_items = LostItem.query.all()
    found_items = FoundItem.query.all()
    return render_template('admin.html', lost_items=lost_items, found_items=found_items)

@main.route('/delete-lost/<int:id>')
@login_required
def delete_lost(id):
    if not current_user.is_admin:
        return redirect(url_for('main.index'))
    item = LostItem.query.get_or_404(id)
    db.session.delete(item)
    db.session.commit()
    return redirect(url_for('main.admin'))

@main.route('/delete-found/<int:id>')
@login_required
def delete_found(id):
    if not current_user.is_admin:
        return redirect(url_for('main.index'))
    item = FoundItem.query.get_or_404(id)
    db.session.delete(item)
    db.session.commit()
    return redirect(url_for('main.admin'))