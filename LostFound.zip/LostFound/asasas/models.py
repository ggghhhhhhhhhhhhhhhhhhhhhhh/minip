from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy

# Import db from app rather than creating a new instance
from app import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

class LostItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner_name = db.Column(db.String(100))
    item_desc = db.Column(db.String(200))
    last_seen_location = db.Column(db.String(100))
    image_url = db.Column(db.String(200), nullable=True)
    status = db.Column(db.String(20), default='Lost')
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('lost_items', lazy=True))

class FoundItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    finder_name = db.Column(db.String(100))
    contact_info = db.Column(db.String(100))
    item_desc = db.Column(db.String(200))
    found_location = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('found_items', lazy=True))